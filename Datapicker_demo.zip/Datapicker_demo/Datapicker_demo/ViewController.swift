//
//  ViewController.swift
//  Datapicker_demo
//
//  Created by MAC on 17/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//var dt = UIDatePicker()
    let dateformater = DateFormatter()

    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()

        textField.inputView = datePicker
        textField.isEnabled = false
        textField.placeholder = "dd/MMMM/yyyy"
        
        
        datePicker.datePickerMode = UIDatePicker.Mode.date
        datePicker.preferredDatePickerStyle = .wheels
       // datePicker.timeZone = NSTimeZone.local
//        datePicker.countDownDuration = 12000
//        datePicker.minuteInterval = 5
        datePicker.addTarget(self, action: #selector(changeDate(datapicker:)), for: .valueChanged)
        
    /*   let calendar = Calendar.current
       var startDate = calendar.dateComponents([.day,.month,.year], from: Date())
       startDate.day = 20
       startDate.month = 01
       startDate.year = 2020
       let minDate = calendar.date(from: startDate)

       var endDate = calendar.dateComponents([.day,.month,.year], from: Date())
       endDate.day = 20
       endDate.month = 01
       endDate.year = 2021
       let maxDate = calendar.date(from: endDate)

       datePicker.minimumDate = minDate! as Date
       datePicker.maximumDate =  maxDate! as Date*/
       //...........................................................
       /* let datePicker = UIDatePicker()
        datePicker.frame = CGRect(x: 5, y: 300, width: 365, height: 200)
        datePicker.timeZone = NSTimeZone.local
        datePicker.backgroundColor = UIColor.cyan
        datePicker.datePickerMode = .countDownTimer
        self.view.addSubview(datePicker)*/
        // Do any additional setup after loading the view.
        
    }
    @objc func changeDate(datapicker: UIDatePicker)
    {
        //let dateformater = DateFormatter()
       // dateformater.dateFormat = "dd MMMM yyyy"
        dateformater.dateFormat = "dd-MMMM-yyyy"
        print("datapicker \(datapicker.date)")
        textField.text = dateformater.string(from: datapicker.date)
        
        let str = textField.text
        let date: Date = dateformater.date(from: str!)!
        print("strdate : \(str!)")
        print("date : \(date)")
        lbl.text = str
        
        view.endEditing(true)
    }

}

